
public abstract class Moveable {
	
	public abstract void move();
	
	public abstract void calculateNextMove();
	
}
